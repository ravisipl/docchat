export function bytesToSize(bytes: number | undefined): string;
